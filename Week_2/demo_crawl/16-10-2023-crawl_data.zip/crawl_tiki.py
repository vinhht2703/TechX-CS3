import random
import requests
import time
import json

headers = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Safari/537.36'
}
params = {
    'limit': '40',
    'include': 'advertisement',
    'aggregations': '2',
    'version': 'home-persionalized',
    'trackity_id': 'b2ee50bb-3965-dd80-67b4-3f6b84ae3737',
    'category': '2549',
    'page': '1',
    'urlKey': 'dien-thoai-may-tinh-bang'
}


products = []
for i in range(1, 100):
    params['page'] = i  # type: ignore
    response = requests.get('https://tiki.vn/api/personalish/v1/blocks/listings', headers=headers, params=params)
    if response.status_code == 200:
        print('request success!!!')
        for record in response.json().get('data'):
            product_data = {
                'id': record.get('id'),
                'name': record.get('name'),
                'brand_name': record.get('brand_name'),
                'original_price': record.get('original_price'),
                'price': record.get('price'),
                'discount': record.get('discount_rate'),
                'thumbnail_url': record.get('thumbnail_url'),
                'quantity_sold': record.get('quantity_sold')
            }
            products.append(product_data)

        # Lưu sau mỗi lần gửi yêu cầu thành công
        with open('products_tiki.json', 'w', encoding='utf-8') as f:
            json.dump(products, f, ensure_ascii=False, indent=4)
    # time.sleep(random.randrange(1, 3))