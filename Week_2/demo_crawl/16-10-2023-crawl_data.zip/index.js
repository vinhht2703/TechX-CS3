const dem = require('./data.json')
console.log(dem[0]);
console.log(dem[1500000]);
console.log(dem[dem.length - 1]);
console.log(dem.length);
